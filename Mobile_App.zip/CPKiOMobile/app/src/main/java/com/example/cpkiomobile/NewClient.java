package com.example.cpkiomobile;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class NewClient extends AppCompatActivity {

    DBHelper dbHelper;
    SQLiteDatabase db;
    EditText code,email,surname,name,midname,address,date,serialNumber,number,phoneNumber;
    Button saveButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_client_activity);
    }

    @Override
    protected void onStart() {
        super.onStart();
        dbHelper = new DBHelper(getApplicationContext());
        db = dbHelper.open();

        code = findViewById(R.id.clientCode);
        surname = findViewById(R.id.clientSurname);
        name = findViewById(R.id.clientSurname);
        midname = findViewById(R.id.clientMidname);
        address = findViewById(R.id.clientAddress);
        date = findViewById(R.id.clientDateOfBirth);
        serialNumber = findViewById(R.id.clientPassportSerialNumber);
        number = findViewById(R.id.clientPassportNumber);
        phoneNumber = findViewById(R.id.clientPhoneNumber);
        email = findViewById(R.id.clientEmail);

        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addNewClient();
            }
        });
    }

    public void addNewClient(){
        ContentValues cv = new ContentValues();
        cv.put("surname",surname.getText().toString());
        cv.put("name",name.getText().toString());
        cv.put("patronymic",midname.getText().toString());
        cv.put("passport_series",serialNumber.getText().toString());
        cv.put("passport_number",number.getText().toString());
        cv.put("dob",date.getText().toString());
        cv.put("adress",address.getText().toString());
        cv.put("email",email.getText().toString());
        db.insert("clients",null,cv);

        db.close();

        toastMaker("Новый клиент успешно добавлен");

        Intent intent = new Intent(getApplicationContext(),WorkSpace.class);
        startActivity(intent);
    }

    public void toastMaker(String toastText){
        Toast toast = Toast.makeText(getApplicationContext(),toastText,Toast.LENGTH_LONG);
        toast.show();
    }
}
