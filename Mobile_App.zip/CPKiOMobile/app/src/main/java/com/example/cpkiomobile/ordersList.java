package com.example.cpkiomobile;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class ordersList extends AppCompatActivity {

    DBHelper dbHelper;
    SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.orders_list_activity);

        ArrayList<HashMap<String,Object>> orders = new ArrayList<HashMap<String,Object>>();

        HashMap<String,Object> order;

        dbHelper = new DBHelper(getApplicationContext());
        db = dbHelper.open();

        Cursor cursor = db.rawQuery("select clients.surname || ' ' ||  clients.name || ' ' || clients.patronymic as fio, services.name from orders,services inner join clients on orders.client_id = clients._id inner join services_list on orders.services_list_id = services._id and services._id = services_list._id",null);
        cursor.moveToFirst();

        while(!cursor.isAfterLast()){
            order = new HashMap<String,Object>();

            order.put("fio",cursor.getString(0));
            order.put("name",cursor.getString(1));

            orders.add(order);

            cursor.moveToNext();
        }
        cursor.close();

        String [] from = {"fio","name"};
        int[] to = {R.id.textView4,R.id.textView5};

        SimpleAdapter adapter = new SimpleAdapter(getApplicationContext(),orders,R.layout.order_list_adapter_item,from,to);
        ListView listView = (ListView) findViewById(R.id.listView1);
        listView.setAdapter(adapter);

    }
}
