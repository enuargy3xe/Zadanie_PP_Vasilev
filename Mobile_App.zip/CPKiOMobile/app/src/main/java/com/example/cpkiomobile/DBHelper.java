package com.example.cpkiomobile;

import android.content.ContentValues;
import android.database.SQLException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.content.Context;
import android.util.Log;

import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DBHelper extends SQLiteOpenHelper {
    public static final int DB_VERSION = 1;
    public static final String DB_NAME = "cpkioSQLite.db";
    public static String DB_PATH = null;

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        DB_PATH = context.getFilesDir().getPath() + DB_NAME;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //sqLiteDatabase.execSQL(Employers.CREATE_TABLE);

        //Один чел в таблицу сотрудников,а больше и не надо же
        //ContentValues contentValues = new ContentValues();
        //ContentValues contentValues2 = new ContentValues();

        //contentValues.put(Employers.COLUMN_NAME,"Вениамин");
        //contentValues.put(Employers.COLUMN_SURNAME,"Миронов");
        //contentValues.put(Employers.COLUMN_MIDNAME,"Куприянович");
        //contentValues.put(Employers.COLUMN_LOGIN,"mironov@namecomp.ru");
        //contentValues.put(Employers.COLUMN_PASSWORD,"YOyhfr");

        //contentValues2.put(Employers.COLUMN_NAME,"Ермолай");
        //contentValues2.put(Employers.COLUMN_SURNAME,"Ширяев");
        //contentValues2.put(Employers.COLUMN_MIDNAME,"Вениаминович");
        //contentValues2.put(Employers.COLUMN_LOGIN,"shiryev@namecomp.ru");
        //contentValues2.put(Employers.COLUMN_PASSWORD,"ez");

        //sqLiteDatabase.insert(Employers.TABLE_NAME,null,contentValues);
        //sqLiteDatabase.insert(Employers.TABLE_NAME,null,contentValues2);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    void createDB(Context context){
        File file = new File(DB_PATH);
        if(!file.exists()){
            try{
                InputStream myInput = context.getAssets().open(DB_NAME);
                OutputStream myOutput = new FileOutputStream(DB_PATH);

                byte[] buffer = new byte[1024];
                int length;
                while ((length = myInput.read(buffer)) > 0) {
                    myOutput.write(buffer, 0, length);
                }
                myOutput.flush();

            }
            catch (IOException ex){
                Log.d("EX",ex.getMessage());
            }
        }
    }

    public SQLiteDatabase open()throws SQLException {

        return SQLiteDatabase.openDatabase(DB_PATH, null, SQLiteDatabase.OPEN_READWRITE);
    }

    //Таблица сотрудников
    public static final class Employers implements BaseColumns{
        public static final String TABLE_NAME = "employers";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_SURNAME = "surname";
        public static final String COLUMN_MIDNAME = "middlename";
        public static final String COLUMN_LOGIN = "login";
        public static final String COLUMN_PASSWORD = "password";
        public static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " +
                TABLE_NAME + " (" +
                _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_SURNAME + " TEXT, " +
                COLUMN_MIDNAME + " TEXT, " +
                COLUMN_LOGIN + " TEXT, " +
                COLUMN_PASSWORD + " TEXT " + ")";


    }
    //Таблица заказов
    public static final class Orders implements BaseColumns{
        public static final String TABLE_NAME = "orders";
        public static final String COLUMN_ORDER_CODE = "order_code";
        public static final String COLUMN_CLIENT_ID = "client_id";
        public static final String COLUMN_SERVICE_LIST_ID = "services_list_id";
        public static final String COLUMN_STATUS_ID = "status_id";
    //    public static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " +
    //            TABLE_NAME + " (" +
    //            _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
    //            COLUMN_ORDER_CODE + " TEXT, " +
    //            COLUMN_CREATION_DATE + " "

    }
}
