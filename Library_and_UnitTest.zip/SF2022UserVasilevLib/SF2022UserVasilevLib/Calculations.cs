﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SF2022UserVasilevLib
{
    public class Calculations
    {
        public static string[] AvailablePeriods(TimeSpan[] startTimes, int[] durations, TimeSpan beginWorkingTime, TimeSpan endWorkingTime, int consultationTime)
        {

            List<string> resultList = new List<string>();
            TimeSpan consultationTimeSpan = new TimeSpan(0, consultationTime, 0);
            TimeSpan OneMin = new TimeSpan(0, 1, 0); 
            TimeSpan Checker = new TimeSpan();

            Checker = beginWorkingTime;
            int triger = -1;

            if (Checker == startTimes[0])
            {
                TimeSpan durationsTimeSpan = new TimeSpan(0, durations[0], 0);
                Checker = startTimes[0] + durationsTimeSpan;
            }

            for (int iX = 0; iX != triger; iX++)
            {
                for (int i = 0; i < consultationTime; i++)
                {
                    Checker = Checker + OneMin;
                    for (int j = 0; j < startTimes.Length; j++)
                    {
                        if (Checker == startTimes[j] && i == consultationTime - 1)
                        {
                            resultList.Add(Checker - consultationTimeSpan + "-" + Checker);
                            Checker = startTimes[j] + new TimeSpan(0, durations[j], 0);
                            i = -1;
                        }
                        else if (Checker == startTimes[j] && i != consultationTime - 1)
                        {
                            Checker = startTimes[j] + new TimeSpan(0, durations[j], 0);
                            i = -1;
                        }
                        else if (Checker != startTimes[j] && i == consultationTime - 1 && iX != -2 && Checker < endWorkingTime)
                        {
                            resultList.Add(Checker - consultationTimeSpan + "-" + Checker);
                            i = -1;
                        }

                        if (Checker == endWorkingTime && i == consultationTime - 1)
                        {
                            resultList.Add(Checker - consultationTimeSpan + "-" + Checker);

                            iX = -2;
                            i = -1;
                        }
                        else if (Checker == endWorkingTime && i != consultationTime - 1)
                        {
                            iX = -2;

                            i = -1;
                        }
                        else if (Checker > endWorkingTime)
                        {
                            iX = -2;
                        }
                    }
                }
            }

            string[] result = new string[resultList.Count];
            for (int i = 0; i < resultList.Count; i++)
            {
                result[i] = resultList[i];
            }
            return result;

        }
    }
}
