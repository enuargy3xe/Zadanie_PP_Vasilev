﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.ComponentModel;
using SF2022UserVasilevLib;

namespace SF2022UserVasilevLibTest
{
    [TestClass]
    public class CalculationTest
    {
        [TestMethod]
        public void ТФ_НУ_1()
        {
            TimeSpan[] startTimes = { new TimeSpan(10, 00, 0), new TimeSpan(11, 00, 0), new TimeSpan(15, 00, 0),
            new TimeSpan(15,30,0),new TimeSpan(16,50,0)};

            TimeSpan beginWorkingTime = new TimeSpan(8, 00, 0);
            TimeSpan endWorkingTime = new TimeSpan(18, 00, 0);
            int consultationTime = 30;

            int[] durations = { 60, 30, 10,10,40 };

            string[] expected = new string[] { "08:00:00-08:30:00", "08:30:00-09:00:00", "09:00:00-09:30:00", "09:30:00-10:00:00", "11:30:00-12:00:00", "12:00:00-12:30:00", "12:30:00-13:00:00", "13:00:00-13:30:00", "13:30:00-14:00:00", "14:00:00-14:30:00", "14:30:00-15:00:00", "15:40:00-16:10:00", "16:10:00-16:40:00", "17:30:00-18:00:00" };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for(int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i],result[i]);
            }
        }
        [TestMethod]
        public void ТФ_НУ_2()
        {
            TimeSpan[] startTimes = { new TimeSpan(10, 00, 0),
                new TimeSpan(14, 00, 0),
                new TimeSpan(16, 00, 0),
                new TimeSpan(20, 00, 0)
            };

            TimeSpan beginWorkingTime = new TimeSpan(9, 00, 0);
            TimeSpan endWorkingTime = new TimeSpan(21, 00, 0);
            int consultationTime = 30;

            int[] durations = { 20, 30, 10, 20};

            string[] expected = new string[] { "09:00:00-09:30:00",
                "09:30:00-10:00:00",
                "10:20:00-10:50:00",
                "10:50:00-11:20:00",
                "11:20:00-11:50:00",
                "11:50:00-12:20:00",
                "12:20:00-12:50:00",
                "12:50:00-13:20:00",
                "13:20:00-13:50:00",
                "14:30:00-15:00:00",
                "15:00:00-15:30:00",
                "15:30:00-16:00:00",
                "16:10:00-16:40:00",
                "16:40:00-17:10:00",
                "17:10:00-17:40:00",
                "17:40:00-18:10:00",
                "18:10:00-18:40:00",
                "18:40:00-19:10:00",
                "19:10:00-19:40:00",
                "20:20:00-20:50:00",
            };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void ТФ_НУ_3()
        {
            TimeSpan[] startTimes = { new TimeSpan(10, 00, 0),
                new TimeSpan(14, 00, 0),
                new TimeSpan(16, 00, 0),
                new TimeSpan(20, 00, 0)
            };

            TimeSpan beginWorkingTime = new TimeSpan(9, 00, 0);
            TimeSpan endWorkingTime = new TimeSpan(14, 00, 0);
            int consultationTime = 50;

            int[] durations = { 20, 30, 10, 20 };

            string[] expected = new string[] { "09:00:00-09:50:00",
                "10:20:00-11:10:00",
                "11:10:00-12:00:00",
                "12:00:00-12:50:00",
                "12:50:00-13:40:00",
            };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void ТФ_НУ_4()
        {
            TimeSpan[] startTimes = { new TimeSpan(10, 00, 0),
            };

            TimeSpan beginWorkingTime = new TimeSpan(7, 00, 0);
            TimeSpan endWorkingTime = new TimeSpan(12, 00, 0);
            int consultationTime = 90;

            int[] durations = { 120 };

            string[] expected = new string[] { "07:00:00-08:30:00",
                "08:30:00-10:00:00",
               
            };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void ТФ_НУ_5()
        {
            TimeSpan[] startTimes = { new TimeSpan(10, 00, 0),
                new TimeSpan(11, 00, 0),
            };

            TimeSpan beginWorkingTime = new TimeSpan(9, 00, 0);
            TimeSpan endWorkingTime = new TimeSpan(12, 00, 0);
            int consultationTime = 10;

            int[] durations = { 40, 5 };

            string[] expected = new string[] { "09:00:00-09:10:00",
                "09:10:00-09:20:00",
                "09:20:00-09:30:00",
                "09:30:00-09:40:00",
                "09:40:00-09:50:00",
                "09:50:00-10:00:00",
                "10:40:00-10:50:00",
                "10:50:00-11:00:00",
                "11:05:00-11:15:00",
                "11:15:00-11:25:00",
                "11:25:00-11:35:00",
                "11:35:00-11:45:00",
                "11:45:00-11:55:00",
            };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void ТФ_НУ_6()
        {
            TimeSpan[] startTimes = { new TimeSpan(16, 20, 0),
            };

            TimeSpan beginWorkingTime = new TimeSpan(15, 30, 0);
            TimeSpan endWorkingTime = new TimeSpan(17, 40, 0);
            int consultationTime = 40;

            int[] durations = { 20};

            string[] expected = new string[] { "15:30:00-16:10:00", "16:40:00-17:20:00",
            };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void ТФ_ЭУ_1()
        {
            TimeSpan[] startTimes = { new TimeSpan(12, 00, 0),
            };

            TimeSpan beginWorkingTime = new TimeSpan(10, 00, 0);
            TimeSpan endWorkingTime = new TimeSpan(14, 00, 0);
            int consultationTime = 40;

            int[] durations = { 229 };

            string[] expected = new string[] { "10:00:00-10:40:00", "10:40:00-11:20:00",
            };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void ТФ_ЭУ_2()
        {
            TimeSpan[] startTimes = { new TimeSpan(12, 00, 0),
            };

            TimeSpan beginWorkingTime = new TimeSpan(10, 00, 0);
            TimeSpan endWorkingTime = new TimeSpan(14, 00, 0);
            int consultationTime = 60;

            int[] durations = { 30,9 };

            string[] expected = new string[] { "10:00:00-11:00:00", "11:00:00-12:00:00","12:30:00-13:30:00",
            };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void ТФ_ИУ_1()
        {
            TimeSpan[] startTimes = { new TimeSpan(0,0,0)
            };

            TimeSpan beginWorkingTime = new TimeSpan(10, 00, 0);
            TimeSpan endWorkingTime = new TimeSpan(12, 00, 0);
            int consultationTime = 60;

            int[] durations = { 30};

            string[] expected = new string[] { "10:00:00-11:00:00", "11:00:00-12:00:00","12:30:00-13:30:00",
            };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void ТФ_ИУ_2()
        {
            TimeSpan[] startTimes = { new TimeSpan(10,0,0)
            };

            TimeSpan beginWorkingTime = new TimeSpan(10, 00, 0);
            TimeSpan endWorkingTime = new TimeSpan(12, 00, 0);
            int consultationTime = 600;

            int[] durations = { 30 };

            string[] expected = new string[] { "10:00:00-11:00:00", "11:00:00-12:00:00","12:30:00-13:30:00",
            };

            string[] result = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);

            for (int i = 0; i < expected.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
    }
}
